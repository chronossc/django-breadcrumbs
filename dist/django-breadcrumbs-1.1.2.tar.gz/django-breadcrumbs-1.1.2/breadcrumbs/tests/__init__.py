# -*- coding: utf-8 -*-
from breadcrumbs.tests.breadcrumbs_tests import *
from breadcrumbs.tests.flatpages_tests import *
